import numpy as np
import pandas as pd
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from scipy.optimize import minimize, minimize_scalar, brentq
import os
from matplotlib.ticker import ScalarFormatter
import csv
from scipy.stats import chi2

n_dataset = 1
fitting_conditions = 0

# Parameters for profile likelihood calculations
n_grid = 101
ci_level = 0.95
chi2_thresh_1 = chi2.ppf(ci_level, df=1)
chi2_thresh_2 = chi2.ppf(ci_level, df=2)

while n_dataset <= 5:
    print('\nDataset = ', n_dataset)
    outdir_pl = f'./dataout/3D_cellgrowth/fitting_donorA'
    outdir_pl_results = f'{outdir_pl}/results'
    outdir_fig_pl = f'./fig/3D_cellgrowth/fitting_donorA'

    os.makedirs(outdir_pl, exist_ok=True)
    os.makedirs(outdir_pl_results, exist_ok=True)
    os.makedirs(outdir_fig_pl, exist_ok=True)
    csv_file1 = f'{outdir_pl}/fitted_params_{n_dataset}.csv'
    csv_file2 = f'{outdir_pl}/fitted_params_CI_{n_dataset}.csv'
    csv_file3 = f'{outdir_pl_results}/fitted_results_{n_dataset}.csv'
    csv_file_profile_C = f'{outdir_pl}/profile_likelihood_C_{n_dataset}.csv'
    csv_file_profile_lambda = f'{outdir_pl}/profile_likelihood_lambda_{n_dataset}.csv'
    png_file1 = f'{outdir_fig_pl}/3D_cellgrowth_CI_{n_dataset}.png'
    png_file2 = f'{outdir_fig_pl}/3D_cellgrowth_contour_{n_dataset}.png'
    png_file3 = f'{outdir_fig_pl}/3D_cellgrowth_LR_contour_{n_dataset}.png'

    data = pd.read_csv(f'./data/8580_3D/data{n_dataset}.csv')
    time = data.iloc[:, 0].values
    X_data = data.iloc[:, 1].values
    if n_dataset == 1:
        time_splits = [0, 7, 10, time[-1]]
        cPDL0 = 2.03
    elif n_dataset == 2:
        time_splits = [0, 6, 10, time[-1]]
        cPDL0 = 6.06
    elif n_dataset == 3:
        time_splits = [0, 8, 12, time[-1]]
        cPDL0 = 8.43
    elif n_dataset == 4:
        time_splits = [0, 6, 10, time[-1]]
        cPDL0 = 1.90
    elif n_dataset == 5:
        time_splits = [0, 7, 11, time[-1]]
        cPDL0 = 6.46

    tau = 4.0

    def dX_dt(vars, t, X_max, C_con, lamda_con):
        X, cPDL = vars
        mu_max = C_con - np.exp(lamda_con * cPDL)
        if mu_max >= 0.0:
            dXdt = (1.0 - np.exp(-t / tau)) * mu_max * (X_max - X) / X_max * X
            dcPDLdt = (1.0 - np.exp(-t / tau)) * mu_max * (X_max - X) / X_max / np.log(2)
        else:
            dXdt = 0.0
            dcPDLdt = 0.0
        return [dXdt, dcPDLdt]

    def solve_ode(C_con, lamda_con):
        X_max = 3.00e5
        X0 = X_data[0]
        initial_conditions = [X0, cPDL0]

        X_results = []
        cPDL_results = []
        time_results = []

        current_conditions = initial_conditions

        for i in range(len(time_splits) - 1):
            time_span = np.linspace(time_splits[i], time_splits[i + 1], num=500)
            solution = odeint(dX_dt, current_conditions, time_span, args=(X_max, C_con, lamda_con))

            if i == 0:
                X = solution[:, 0]
                cPDL = solution[:, 1]
                X_transit = X[-1]/5
            else:
                X = solution[1:, 0]
                cPDL = solution[1:, 1]
                X_transit = X[-1]/5
                time_span = time_span[1:]

            current_conditions = [X_transit, cPDL[-1]]

            X_results.append(X)
            cPDL_results.append(cPDL)
            time_results.append(time_span)

        X_combined = np.concatenate(X_results)
        cPDL_combined = np.concatenate(cPDL_results)
        time_combined = np.concatenate(time_results)

        return time_combined, X_combined, cPDL_combined

    def NRMSE(params):
        C_con, lamda_con = params
        time_sim, simulated_X, _ = solve_ode(C_con, lamda_con)
        interpolated_X = np.interp(time, time_sim, simulated_X)
        nrmse = np.sqrt(np.mean((X_data - interpolated_X) ** 2)) / (X_data.max() - X_data.min())
        return nrmse

    def gaussian_log_likelihood(params):
        C_con, lamda_con = params
        time_sim, simulated_X, _ = solve_ode(C_con, lamda_con)
        interpolated_X = np.interp(time, time_sim, simulated_X)
        residuals = X_data - interpolated_X
        n = len(X_data)
        sse = np.sum(residuals ** 2)
        sigma2_hat = max(sse / n, 1e-12)
        log_l = -n / 2.0 * (np.log(2.0 * np.pi * sigma2_hat) + 1.0)
        return log_l

    def neg_log_likelihood(params):
        return -gaussian_log_likelihood(params)

    bnds = ((1.40, 2.00), (0, 0.04))
    initial_guess = [1.6127576008923308, 0.01]
    C_grid = np.linspace(bnds[0][0], bnds[0][1], n_grid)
    lam_grid = np.linspace(bnds[1][0], bnds[1][1], n_grid)

    time_sim_ref, _, _ = solve_ode(C_grid[0], lam_grid[0])
    LL_grid = np.zeros((n_grid, n_grid))          # LL_grid[i, j] : C_grid[i], lam_grid[j]
    X_grid_stack = np.zeros((n_grid, n_grid, len(time_sim_ref)))

    for i, C_val in enumerate(C_grid):
        for j, lam_val in enumerate(lam_grid):
            _, X_g, _ = solve_ode(C_val, lam_val)
            X_grid_stack[i, j, :] = X_g
            LL_grid[i, j] = gaussian_log_likelihood([C_val, lam_val])

    if fitting_conditions == 0:
        result_initial = minimize(neg_log_likelihood, initial_guess, method='Nelder-Mead', bounds=bnds)
        i_best, j_best = np.unravel_index(np.argmax(LL_grid), LL_grid.shape)
        grid_best_guess = [C_grid[i_best], lam_grid[j_best]]
        result_grid = minimize(neg_log_likelihood, grid_best_guess, method='Nelder-Mead', bounds=bnds)
        result = min([result_initial, result_grid], key=lambda r: r.fun)

    C_con_fit, lamda_con_fit = result.x
    logL_max = -result.fun
    logL_max = max(logL_max, LL_grid.max())
    nrmse = NRMSE(result.x)
    print(f"Fitted C_con: {C_con_fit:.4f}")
    print(f"Fitted lamda_con: {lamda_con_fit:.4f}")
    print(f"Fixed tau_con: {tau:.2f}")
    print(f"Log-likelihood (max): {logL_max:.4f}")
    print(f"NRMSE = {nrmse:.4f}")

    time_sim, X_sim, cPDL_sim = solve_ode(C_con_fit, lamda_con_fit)

    LR_grid = 2.0 * (logL_max - LL_grid)
    rel_L_grid = np.exp(LL_grid - logL_max)

    joint_mask = LR_grid <= chi2_thresh_2
    if not joint_mask.any():
        joint_mask[np.unravel_index(np.argmin(LR_grid), LR_grid.shape)] = True
    X_ci_lower = np.minimum(X_grid_stack[joint_mask].min(axis=0), X_sim)
    X_ci_upper = np.maximum(X_grid_stack[joint_mask].max(axis=0), X_sim)

    profile_logL_C = LL_grid.max(axis=1)
    profile_LR_C = 2.0 * (logL_max - profile_logL_C)

    profile_logL_lam = LL_grid.max(axis=0)
    profile_LR_lam = 2.0 * (logL_max - profile_logL_lam)

    def profile_logL_fixed_C(C_val):
        res = minimize_scalar(lambda lam: -gaussian_log_likelihood([C_val, lam]),
                               bounds=bnds[1], method='bounded')
        return -res.fun

    def profile_logL_fixed_lam(lam_val):
        res = minimize_scalar(lambda C: -gaussian_log_likelihood([C, lam_val]),
                               bounds=bnds[0], method='bounded')
        return -res.fun

    def refine_ci_bound(grid, profile_lr, threshold, profile_func):
        idx_min = int(np.argmin(profile_lr))

        lower = grid[0]
        lower_hit_boundary = True
        for i in range(idx_min, 0, -1):
            if profile_lr[i - 1] > threshold:
                a, b = grid[i - 1], grid[i]
                f = lambda v: 2.0 * (logL_max - profile_func(v)) - threshold
                try:
                    lower = brentq(f, a, b, xtol=1e-8)
                except ValueError:
                    lower = a
                lower_hit_boundary = False
                break

        upper = grid[-1]
        upper_hit_boundary = True
        for i in range(idx_min, len(grid) - 1):
            if profile_lr[i + 1] > threshold:
                a, b = grid[i], grid[i + 1]
                f = lambda v: 2.0 * (logL_max - profile_func(v)) - threshold
                try:
                    upper = brentq(f, a, b, xtol=1e-8)
                except ValueError:
                    upper = b
                upper_hit_boundary = False
                break

        return lower, upper, lower_hit_boundary, upper_hit_boundary

    C_ci_lower, C_ci_upper, C_lower_hit, C_upper_hit = refine_ci_bound(
        C_grid, profile_LR_C, chi2_thresh_1, profile_logL_fixed_C)
    lam_ci_lower, lam_ci_upper, lam_lower_hit, lam_upper_hit = refine_ci_bound(
        lam_grid, profile_LR_lam, chi2_thresh_1, profile_logL_fixed_lam)

    dx = 10 if (C_con_fit - C_grid[0]) < (C_grid[-1] - C_con_fit) else -10
    dy = 10 if (lamda_con_fit - lam_grid[0]) < (lam_grid[-1] - lamda_con_fit) else -10
    mle_label_offset = (dx, dy)
    mle_label_ha = 'left' if dx > 0 else 'right'
    mle_label_va = 'bottom' if dy > 0 else 'top'

    print(f"Profile likelihood 95% CI for C_con: {C_ci_lower:.4f} - {C_ci_upper:.4f}"
          + (" (bnd)" if C_lower_hit or C_upper_hit else ""))
    print(f"Profile likelihood 95% CI for lamda_con: {lam_ci_lower:.6f} - {lam_ci_upper:.6f}"
          + (" (bnd)" if lam_lower_hit or lam_upper_hit else ""))
    if C_lower_hit or C_upper_hit or lam_lower_hit or lam_upper_hit:
        print("  -> 95% confidence interval reaches the parameter search bounds (bnds)")

    data = {
        "Parameter": ["C_con_fit", "lamda_con_fit", "tau_con_fit", "NRMSE", "LogLikelihood_max",
                      "C_bnd_min", "C_bnd_max", "lamda_bnd_min", "lamda_bnd_max"],
        "Value": [C_con_fit, lamda_con_fit, tau, nrmse, logL_max,
                  bnds[0][0], bnds[0][1], bnds[1][0], bnds[1][1]]
    }
    df = pd.DataFrame(data)
    df.to_csv(csv_file1, index=False)

    data_ci = {
        "Parameter": ["C", "C_lower", "C_upper", "lambda", "lambda_lower", "lambda_upper",
                      "LogLikelihood_max", "chi2_threshold_df1", "chi2_threshold_df2"],
        "Value": [C_con_fit, C_ci_lower, C_ci_upper, lamda_con_fit, lam_ci_lower, lam_ci_upper,
                  logL_max, chi2_thresh_1, chi2_thresh_2]
    }
    df_ci = pd.DataFrame(data_ci)
    df_ci.to_csv(csv_file2, index=False)

    pd.DataFrame({
        'C_con': C_grid,
        'LogLikelihood': profile_logL_C,
        'LR_statistic': profile_LR_C,
        'lamda_con_opt': lam_grid[np.argmax(LL_grid, axis=1)],
    }).to_csv(csv_file_profile_C, index=False)

    pd.DataFrame({
        'lamda_con': lam_grid,
        'LogLikelihood': profile_logL_lam,
        'LR_statistic': profile_LR_lam,
        'C_con_opt': C_grid[np.argmax(LL_grid, axis=0)],
    }).to_csv(csv_file_profile_lambda, index=False)

    C_grid_mesh, lam_grid_mesh = np.meshgrid(C_grid, lam_grid, indexing='ij')
    pd.DataFrame({
        'C_con': C_grid_mesh.flatten(),
        'lamda_con': lam_grid_mesh.flatten(),
        'LogLikelihood': LL_grid.flatten(),
        'LR_statistic': LR_grid.flatten(),
        'Relative_likelihood': rel_L_grid.flatten(),
    }).to_csv(f'{outdir_pl}/likelihood_surface_{n_dataset}.csv', index=False)

    font = {'family': 'Arial', 'size': 18}
    legend_font = {'family': 'Arial', 'size': 18}
    plt.figure(figsize=(8, 6))
    plt.plot(time, X_data, 'ro', label='Experimental data')
    plt.plot(time_sim, X_sim, '-', label='Simulation', linewidth=2, color='blue')
    plt.fill_between(time_sim, X_ci_lower, X_ci_upper,
                    color='blue', alpha=0.1, label='95% CI (profile likelihood)')
    plt.xlabel('Time [days]', fontdict=font)
    plt.ylabel('Cell count [–]', fontdict=font)
    plt.xticks(fontsize=16, fontname='Arial')
    plt.yticks(fontsize=16, fontname='Arial')
    plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
    formatter = ScalarFormatter(useMathText=True)
    formatter.set_powerlimits((4, 4))  # Force 10^4 formatting
    plt.gca().yaxis.set_major_formatter(formatter)
    plt.gca().yaxis.offsetText.set_fontsize(16)
    plt.tick_params(left=False, bottom=False)
    plt.legend(prop=legend_font, frameon=False)
    plt.savefig(png_file1, dpi=400, bbox_inches='tight')
    plt.close()

    plt.figure(figsize=(8, 6))
    cs1 = plt.contourf(C_grid, lam_grid, rel_L_grid.T, levels=40, cmap='viridis')
    cbar1 = plt.colorbar(cs1)
    cbar1.set_label(r'Relative likelihood  $L/L_{max}$', fontsize=16, fontname='Arial')
    cbar1.ax.tick_params(labelsize=14)
    plt.contour(C_grid, lam_grid, rel_L_grid.T, levels=40, colors='k', linewidths=0.2, alpha=0.4)
    plt.plot(C_con_fit, lamda_con_fit, marker='*', color='red', markeredgecolor='white', markersize=18)
    plt.annotate('MLE', xy=(C_con_fit, lamda_con_fit), xytext=mle_label_offset, textcoords='offset points',
                 ha=mle_label_ha, va=mle_label_va, color='white', fontsize=16, fontname='Arial')
    plt.xlabel('C', fontdict=font)
    plt.ylabel(r'$\lambda$', fontdict=font)
    plt.xticks(fontsize=16, fontname='Arial')
    plt.yticks(fontsize=16, fontname='Arial')
    plt.savefig(png_file2, dpi=400, bbox_inches='tight')
    plt.close()

    plt.figure(figsize=(8, 6))
    cs2 = plt.contourf(C_grid, lam_grid, LR_grid.T, levels=40, cmap='viridis_r')
    cbar2 = plt.colorbar(cs2)
    cbar2.set_label(r'Likelihood ratio statistic  $-2\Delta \log L$', fontsize=16, fontname='Arial')
    cbar2.ax.tick_params(labelsize=14)
    ci_contour = plt.contour(C_grid, lam_grid, LR_grid.T, levels=[chi2_thresh_2],
                              colors='red', linewidths=2.5)
    plt.clabel(ci_contour, fmt={chi2_thresh_2: '95% CI'}, fontsize=14)
    plt.plot(C_con_fit, lamda_con_fit, marker='*', color='white', markeredgecolor='black', markersize=18)
    plt.annotate('MLE', xy=(C_con_fit, lamda_con_fit), xytext=mle_label_offset, textcoords='offset points',
                 ha=mle_label_ha, va=mle_label_va, color='black', fontsize=16, fontname='Arial')
    plt.xlabel('C', fontdict=font)
    plt.ylabel(r'$\lambda$', fontdict=font)
    plt.xticks(fontsize=16, fontname='Arial')
    plt.yticks(fontsize=16, fontname='Arial')
    plt.savefig(png_file3, dpi=400, bbox_inches='tight')
    plt.close()

    result_df = pd.DataFrame({
        'Time': time_sim,
        'X': X_sim,
        'cPDL': cPDL_sim,
        'X_CI_lower': X_ci_lower,
        'X_CI_upper': X_ci_upper,
    })
    result_df.to_csv(csv_file3, index=False)
    
    def f_cPDL(cPDL, conc, lamda):
        mu_max = (conc - np.exp(cPDL * lamda))
        return mu_max

    cPDL_pred = np.linspace(0, 20, 101)
    mumax_pred = f_cPDL(cPDL_pred, C_con_fit, lamda_con_fit)

    result_mu_df = pd.DataFrame({
        'cPDL': cPDL_pred,
        'mu_max': mumax_pred,
    })
    result_mu_df.to_csv(f'{outdir_pl_results}/fitted_mumax_CI_{n_dataset}.csv', index=False)

    n_dataset += 1
