import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, minimize_scalar, brentq
from scipy.stats import chi2
import matplotlib.pyplot as plt
import os

i_cell = 2
cell_type = ['2827', '8580', '8331']

# Constants and initial conditions
alpha = 0.552
tau = 4.0
beta = -25.2
gamma = 274.0
X_A_seed_base = 1.0
X_A_max = 20.0 * 1.0e+4
V = 100.0
S = 100.0
r_V = 0.99
X_A_seed = 5000.0
X_A_seed_count = 1.35 * 1.0e+6
X_A_ini = X_A_seed
X_S_ini = (X_A_seed_count * r_V - X_A_ini * S) / V

# Parameter settings for profile likelihood calculations
n_grid = 101
ci_level = 0.95
chi2_thresh_1 = chi2.ppf(ci_level, df=1)
chi2_thresh_2 = chi2.ppf(ci_level, df=2)

outdir = f'./dataout/2D_cellgrowth/{cell_type[i_cell]}'
os.makedirs(f'{outdir}/results', exist_ok=True)
out_file = f'{outdir}/fitted_params.csv'
out_file2 = f'{outdir}/fitted_params_CI.csv'
csv_file_profile_C = f'{outdir}/profile_likelihood_C.csv'
csv_file_profile_lambda = f'{outdir}/profile_likelihood_lambda.csv'
csv_file_likelihood_surface = f'{outdir}/likelihood_surface.csv'

outdir_figs = f'./fig/2D_cellgrowth/{cell_type[i_cell]}'
os.makedirs(outdir_figs, exist_ok=True)
outfile_fig1_1 = f'{outdir_figs}/cell_growth_CI.png'
outfile_fig2 = f'{outdir_figs}/mumax.png'
outfile_fig3 = f'{outdir_figs}/likelihood_contour.png'
outfile_fig4 = f'{outdir_figs}/LR_contour.png'

if cell_type[i_cell] == '2827':
    training_points = 7
    initial_guess = [1.04395641, 0.00201227]
    labels = ['p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9']
    labels_fitted = labels[:training_points]
    labels_extrapolated = labels[training_points:]
elif cell_type[i_cell] == '8580':
    training_points = 8
    initial_guess = [1.5, 1.0e-2]
    labels = ['p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10']
    labels_fitted = labels[:training_points]
    labels_extrapolated = labels[training_points:]
elif cell_type[i_cell] == '8331':
    training_points = 11
    initial_guess = [1.05140876e+00, 6.96995838e-02]
    labels = ['p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10', 'p11', 'p12', 'p13']
    labels_fitted = labels[:training_points]
    labels_extrapolated = labels[training_points:]
else:
    print(f'ERROR: Passage numbers for cell type {cell_type[i_cell]} not defined!')

cell_data = {}
for label in labels:
    infile = f'./data/{cell_type[i_cell]}/{cell_type[i_cell]}_celldata_{label}.csv'
    cell_data[label] = pd.read_csv(infile)

all_cell_nums = np.concatenate([cell_data[label]['cell_num'].values for label in labels])
cell_num_range = all_cell_nums.max() - all_cell_nums.min()

def dX_dt(t, y, t_lag, C_con, lambda_con):
    X_S, X_A, cPDL = y
    Pr_a_val = alpha / tau * np.exp(-t / tau)
    sigma_mu_val = 1 if t >= t_lag else 0
    mu_max = (C_con - np.exp(lambda_con * cPDL)) / 24
    if mu_max >= 0.0:
        mu_val = mu_max * (X_A_max - X_A) / X_A_max
        dX_S_dt = 1.0 / V * (-Pr_a_val * V * X_S)
        dX_A_dt = 1.0 / S * (Pr_a_val * V * X_S + sigma_mu_val * mu_val * S * X_A)
        dcPDL_dt = (sigma_mu_val * mu_val * S * X_A) / ((V * X_S + S * X_A) * np.log(2))
    else:
        dX_S_dt = 0
        dX_A_dt = 0
        dcPDL_dt = 0
    return [dX_S_dt, dX_A_dt, dcPDL_dt]

def solve_ode(C_con, lambda_con, cell_data):
    X_A_seed_count = cell_data[cell_data['time']==0]['cell_num'].values[0]
    X_A_ini = 0.0
    X_S_ini = (X_A_seed_count * r_V) / V
    X_A_seed = X_A_seed_count / S

    t_lag = beta * np.log(X_A_seed / X_A_seed_base) + gamma

    t_span = (0, cell_data['time'].max())
    t_eval = np.linspace(0, t_span[1], 1000)
    cPDL0 = cell_data['cPDL'][0]

    sol = solve_ivp(dX_dt, t_span, [X_S_ini, X_A_ini, cPDL0], args=(t_lag, C_con, lambda_con), t_eval=t_eval)
    cell_number_total_simulated = sol.y[0] * V + sol.y[1] * S
    cPDL_simulated = sol.y[2]

    return t_eval, cell_number_total_simulated, cPDL_simulated

def residuals_each(params, data):
    C_con, lambda_con = params
    time_sim, simulated_X, _ = solve_ode(C_con, lambda_con, data)
    time = data['time'].values
    X_data = data['cell_num'].values

    interpolated_X = np.interp(time, time_sim, simulated_X)
    resid_seed = X_data[0] - interpolated_X[0]
    resid_end = X_data[-1] - interpolated_X[-1]
    return resid_seed, resid_end

def normalized_residuals_each(params, data):
    resid_seed, resid_end = residuals_each(params, data)
    return resid_seed / cell_num_range, resid_end / cell_num_range

def sse_over_labels(params, label_list):
    sse = 0.0
    for label in label_list:
        resid_seed, resid_end = normalized_residuals_each(params, cell_data[label])
        sse += resid_seed ** 2 + resid_end ** 2
    return sse

def NRMSE_over_labels(params, label_list):
    if len(label_list) == 0:
        return np.nan
    nrmse_array = []
    for label in label_list:
        resid_seed, resid_end = residuals_each(params, cell_data[label])
        mse = (resid_seed ** 2 + resid_end ** 2) / 2.0
        nrmse_array.append(np.sqrt(mse) / cell_num_range)
    return np.mean(nrmse_array)

n_obs_fitted = 2 * len(labels_fitted)

def gaussian_log_likelihood(params):
    sse = sse_over_labels(params, labels_fitted)
    sigma2_hat = max(sse / n_obs_fitted, 1e-12)
    log_l = -n_obs_fitted / 2.0 * (np.log(2.0 * np.pi * sigma2_hat) + 1.0)
    return log_l

def neg_log_likelihood(params):
    return -gaussian_log_likelihood(params)

bnd = ((1.4, 2.6), (0, 4.0e-2))
C_grid = np.linspace(bnd[0][0], bnd[0][1], n_grid)
lam_grid = np.linspace(bnd[1][0], bnd[1][1], n_grid)

LL_grid = np.zeros((n_grid, n_grid))  # LL_grid[i, j] : C_grid[i], lam_grid[j]
for i, C_val in enumerate(C_grid):
    for j, lam_val in enumerate(lam_grid):
        LL_grid[i, j] = gaussian_log_likelihood([C_val, lam_val])

result_initial = minimize(neg_log_likelihood, initial_guess, method='Nelder-Mead', bounds=bnd)
i_best, j_best = np.unravel_index(np.argmax(LL_grid), LL_grid.shape)
grid_best_guess = [C_grid[i_best], lam_grid[j_best]]
result_grid = minimize(neg_log_likelihood, grid_best_guess, method='Nelder-Mead', bounds=bnd)
result = min([result_initial, result_grid], key=lambda r: r.fun)
print(result)

C_con_fit = result.x[0]
lambda_con_fit = result.x[1]
logL_max = -result.fun
logL_max = max(logL_max, LL_grid.max())

nrmse_fitted = NRMSE_over_labels(result.x, labels_fitted)
nrmse_extrapolated = NRMSE_over_labels(result.x, labels_extrapolated)
nrmse_whole = NRMSE_over_labels(result.x, labels)

print(f"Fitted C_con: {C_con_fit:.4f}")
print(f"Fitted lambda_con: {lambda_con_fit:.6f}")
print(f"Log-likelihood (max): {logL_max:.4f}")
print(f"NRMSE (fitted) = {nrmse_fitted:.4f}")
print(f"NRMSE (extrapolated) = {nrmse_extrapolated:.4f}")
print(f"NRMSE (whole) = {nrmse_whole:.4f}")

LR_grid = 2.0 * (logL_max - LL_grid)
rel_L_grid = np.exp(LL_grid - logL_max)

profile_logL_C = LL_grid.max(axis=1)
profile_LR_C = 2.0 * (logL_max - profile_logL_C)

profile_logL_lam = LL_grid.max(axis=0)
profile_LR_lam = 2.0 * (logL_max - profile_logL_lam)

def profile_logL_fixed_C(C_val):
    res = minimize_scalar(lambda lam: -gaussian_log_likelihood([C_val, lam]),
                           bounds=bnd[1], method='bounded')
    return -res.fun

def profile_logL_fixed_lam(lam_val):
    res = minimize_scalar(lambda C: -gaussian_log_likelihood([C, lam_val]),
                           bounds=bnd[0], method='bounded')
    return -res.fun

def refine_ci_bound(grid, profile_lr, threshold, profile_func):
    idx_min = int(np.argmin(profile_lr))

    lower = grid[0]
    lower_hit_boundary = True
    for i in range(idx_min, 0, -1):
        if profile_lr[i - 1] > threshold:
            a, b = grid[i - 1], grid[i]
            f = lambda v: 2.0 * (logL_max - profile_func(v)) - threshold
            try:
                lower = brentq(f, a, b, xtol=1e-8)
            except ValueError:
                lower = a
            lower_hit_boundary = False
            break

    upper = grid[-1]
    upper_hit_boundary = True
    for i in range(idx_min, len(grid) - 1):
        if profile_lr[i + 1] > threshold:
            a, b = grid[i], grid[i + 1]
            f = lambda v: 2.0 * (logL_max - profile_func(v)) - threshold
            try:
                upper = brentq(f, a, b, xtol=1e-8)
            except ValueError:
                upper = b
            upper_hit_boundary = False
            break

    return lower, upper, lower_hit_boundary, upper_hit_boundary

C_ci_lower, C_ci_upper, C_lower_hit, C_upper_hit = refine_ci_bound(
    C_grid, profile_LR_C, chi2_thresh_1, profile_logL_fixed_C)
lam_ci_lower, lam_ci_upper, lam_lower_hit, lam_upper_hit = refine_ci_bound(
    lam_grid, profile_LR_lam, chi2_thresh_1, profile_logL_fixed_lam)

print(f"Profile likelihood 95% CI for C_con: {C_ci_lower:.4f} - {C_ci_upper:.4f}"
      + (" (bnd)" if C_lower_hit or C_upper_hit else ""))
print(f"Profile likelihood 95% CI for lambda_con: {lam_ci_lower:.6f} - {lam_ci_upper:.6f}"
      + (" (bnd)" if lam_lower_hit or lam_upper_hit else ""))
if C_lower_hit or C_upper_hit or lam_lower_hit or lam_upper_hit:
    print("  -> 95% confidence interval reaches the parameter search bounds (bnd); "
          "consider widening bnd if a closed interval is required.")

joint_mask = LR_grid <= chi2_thresh_2
if not joint_mask.any():
    joint_mask[np.unravel_index(np.argmin(LR_grid), LR_grid.shape)] = True
idx_i_joint, idx_j_joint = np.where(joint_mask)
print(f"Joint 95% confidence region: {len(idx_i_joint)} / {n_grid * n_grid} grid points")

dx = 10 if (C_con_fit - C_grid[0]) < (C_grid[-1] - C_con_fit) else -10
dy = 10 if (lambda_con_fit - lam_grid[0]) < (lam_grid[-1] - lambda_con_fit) else -10
mle_label_offset = (dx, dy)
mle_label_ha = 'left' if dx > 0 else 'right'
mle_label_va = 'bottom' if dy > 0 else 'top'

data = {
    "Parameter": ["C_con_fit", "lambda_con_fit", "NRMSE_fitted", "NRMSE_extrapolated", "NRMSE_whole",
                  "LogLikelihood_max", "C_bnd_min", "C_bnd_max", "lambda_bnd_min", "lambda_bnd_max"],
    "Value": [C_con_fit, lambda_con_fit, nrmse_fitted, nrmse_extrapolated, nrmse_whole,
              logL_max, bnd[0][0], bnd[0][1], bnd[1][0], bnd[1][1]]
}
df = pd.DataFrame(data)
df.to_csv(out_file, index=False)

data_ci = {
    "Parameter": ["C", "C_lower", "C_upper", "lambda", "lambda_lower", "lambda_upper",
                  "LogLikelihood_max", "chi2_threshold_df1", "chi2_threshold_df2"],
    "Value": [C_con_fit, C_ci_lower, C_ci_upper, lambda_con_fit, lam_ci_lower, lam_ci_upper,
              logL_max, chi2_thresh_1, chi2_thresh_2]
}
df_ci = pd.DataFrame(data_ci)
df_ci.to_csv(out_file2, index=False)

pd.DataFrame({
    'C_con': C_grid,
    'LogLikelihood': profile_logL_C,
    'LR_statistic': profile_LR_C,
    'lambda_con_opt': lam_grid[np.argmax(LL_grid, axis=1)],
}).to_csv(csv_file_profile_C, index=False)

pd.DataFrame({
    'lambda_con': lam_grid,
    'LogLikelihood': profile_logL_lam,
    'LR_statistic': profile_LR_lam,
    'C_con_opt': C_grid[np.argmax(LL_grid, axis=0)],
}).to_csv(csv_file_profile_lambda, index=False)

C_grid_mesh, lam_grid_mesh = np.meshgrid(C_grid, lam_grid, indexing='ij')
pd.DataFrame({
    'C_con': C_grid_mesh.flatten(),
    'lambda_con': lam_grid_mesh.flatten(),
    'LogLikelihood': LL_grid.flatten(),
    'LR_statistic': LR_grid.flatten(),
    'Relative_likelihood': rel_L_grid.flatten(),
    'In_joint_95CI': joint_mask.flatten(),
}).to_csv(csv_file_likelihood_surface, index=False)

def growth_curve_with_ci(label):
    time_sim, X_sim, cPDL_sim = solve_ode(C_con_fit, lambda_con_fit, cell_data[label])
    X_lower = X_sim.copy()
    X_upper = X_sim.copy()
    for gi, gj in zip(idx_i_joint, idx_j_joint):
        _, X_g, _ = solve_ode(C_grid[gi], lam_grid[gj], cell_data[label])
        np.minimum(X_lower, X_g, out=X_lower)
        np.maximum(X_upper, X_g, out=X_upper)
    return time_sim, X_sim, cPDL_sim, X_lower, X_upper

if cell_type[i_cell] == '2827':
    fig, axs = plt.subplots(2, 4, figsize=(20, 8), sharey=True)
    axs = axs.flatten()
    ymax = 1.0e7
elif cell_type[i_cell] == '8580':
    fig, axs = plt.subplots(2, 4, figsize=(20, 8), sharey=True)
    axs = axs.flatten()
    ymax = 1.0e7
elif cell_type[i_cell] == '8331':
    fig, axs = plt.subplots(3, 4, figsize=(20, 12), sharey=True)
    axs = axs.flatten()
    ymax = 1.8e7

for i, label in enumerate(labels):
    time = cell_data[label]['time']
    X_data = cell_data[label]['cell_num']
    time_sim, simulated_X, cPDL_fit, X_ci_lower, X_ci_upper = growth_curve_with_ci(label)

    axs[i].plot(time, X_data, 'ro', label='Observed')
    axs[i].plot(time_sim, simulated_X, label='Simulated')
    axs[i].fill_between(time_sim, X_ci_lower, X_ci_upper,
                        color='blue', alpha=0.1, label='95% CI (profile likelihood)')
    axs[i].set_title(f'Passage = {label}',fontsize=18)
    axs[i].set_xlabel('Time', fontsize=16)
    axs[i].set_ylabel('Cell Count', fontsize=16)
    axs[i].set_ylim(0,ymax)
    #axs[i].legend(fontsize=14)
    axs[i].tick_params(axis='both', which='major', labelsize=14)

    result_df = pd.DataFrame({
    'Time': time_sim,
    'X': simulated_X,
    'cPDL': cPDL_fit,
    'X_CI_lower': X_ci_lower,
    'X_CI_upper': X_ci_upper,
    })
    result_df.to_csv(f'{outdir}/results/fitted_results_{label}.csv', index=False)

for j in range(i + 1, len(axs)):
    fig.delaxes(axs[j])

plt.tight_layout()
plt.savefig(outfile_fig1_1, dpi=400, bbox_inches='tight')
# plt.show()

infile = f'./data/{cell_type[i_cell]}/{cell_type[i_cell]}_celldata_mumax.csv'
mumax_df = pd.read_csv(infile)
cPDL_data = mumax_df['cPDL']
mumax_data = mumax_df['mu_max']
cPDL_data = np.array(cPDL_data)
mumax_data = np.array(mumax_data)
mumax_data = mumax_data * 24 # per day

def f_cPDL_2D(cPDL, conc, lamda):
    mu_max = (conc - np.exp(cPDL * lamda))
    return mu_max # per day

params = result.x
cPDL_pred = np.linspace(0, 40, 100)
mumax_pred = f_cPDL_2D(cPDL_pred, *params)

mumax_grid_masked = np.array([
    f_cPDL_2D(cPDL_pred, C_grid[gi], lam_grid[gj]) for gi, gj in zip(idx_i_joint, idx_j_joint)
])
mumax_lower = np.minimum(mumax_grid_masked.min(axis=0), mumax_pred)
mumax_upper = np.maximum(mumax_grid_masked.max(axis=0), mumax_pred)

result_mu_df = pd.DataFrame({
    'cPDL': cPDL_pred,
    'mu_max': mumax_pred,
    'mu_max_CI_lower': mumax_lower,
    'mu_max_CI_upper': mumax_upper,
})
result_mu_df.to_csv(f'{outdir}/results/fitted_mumax_CI.csv', index=False)

plt.figure(figsize=(8,8))
plt.plot(cPDL_pred, mumax_pred, 'b')
plt.plot(cPDL_data, mumax_data, 'o', color='red')
plt.fill_between(cPDL_pred, mumax_lower, mumax_upper, color='skyblue', alpha=0.3)
#plt.legend(frameon=False)
# plt.tick_params(left=False, bottom=False)
plt.xlabel('cPDL', fontsize=14)
plt.ylabel('mu_max [day$^{-1}$]', fontsize=14)
#plt.grid()
plt.xlim(0,40)
plt.ylim(0,1.4)
plt.tick_params(axis='both', which='both', labelsize=12, direction='in', size=8)
plt.xticks([0,10,20,30,40], fontsize=14, y=-0.02)
plt.yticks(fontsize=14, x=-0.01)
plt.savefig(outfile_fig2, dpi=400, bbox_inches='tight')
# plt.show()

font = {'family': 'Arial', 'size': 18}

# 1. 相対尤度 (L/L_max) をz軸としたC-lambdaの等高線図（bnd全域、粗いグリッド）
plt.figure(figsize=(8, 6))
cs1 = plt.contourf(C_grid, lam_grid, rel_L_grid.T, levels=40, cmap='viridis')
cbar1 = plt.colorbar(cs1)
cbar1.set_label(r'Relative likelihood  $L/L_{max}$', fontsize=16, fontname='Arial')
cbar1.ax.tick_params(labelsize=14)
plt.contour(C_grid, lam_grid, rel_L_grid.T, levels=40, colors='k', linewidths=0.2, alpha=0.4)
plt.plot(C_con_fit, lambda_con_fit, marker='*', color='red', markeredgecolor='white', markersize=18)
plt.annotate('MLE', xy=(C_con_fit, lambda_con_fit), xytext=mle_label_offset, textcoords='offset points',
             ha=mle_label_ha, va=mle_label_va, color='white', fontsize=16, fontname='Arial')
plt.xlabel('C', fontdict=font)
plt.ylabel(r'$\lambda$', fontdict=font)
plt.xticks(fontsize=16, fontname='Arial')
plt.yticks(fontsize=16, fontname='Arial')
plt.savefig(outfile_fig3, dpi=400, bbox_inches='tight')
plt.close()

plt.figure(figsize=(8, 6))
cs2 = plt.contourf(C_grid, lam_grid, LR_grid.T, levels=40, cmap='viridis_r')
cbar2 = plt.colorbar(cs2)
cbar2.set_label(r'Likelihood ratio statistic  $-2\Delta \log L$', fontsize=16, fontname='Arial')
cbar2.ax.tick_params(labelsize=14)
ci_contour = plt.contour(C_grid, lam_grid, LR_grid.T, levels=[chi2_thresh_2],
                          colors='red', linewidths=2.5)
plt.clabel(ci_contour, fmt={chi2_thresh_2: '95% CI'}, fontsize=14)
plt.plot(C_con_fit, lambda_con_fit, marker='*', color='white', markeredgecolor='black', markersize=18)
plt.annotate('MLE', xy=(C_con_fit, lambda_con_fit), xytext=mle_label_offset, textcoords='offset points',
             ha=mle_label_ha, va=mle_label_va, color='black', fontsize=16, fontname='Arial')
plt.xlabel('C', fontdict=font)
plt.ylabel(r'$\lambda$', fontdict=font)
plt.xticks(fontsize=16, fontname='Arial')
plt.yticks(fontsize=16, fontname='Arial')
plt.savefig(outfile_fig4, dpi=400, bbox_inches='tight')
plt.close()
